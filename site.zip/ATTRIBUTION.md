# 来源与许可

## IPIP

IPIP 题目与量表属于公共领域，见 <https://ipip.ori.org/newPermission.htm>。

- 300 题原始计分键：<https://ipip.ori.org/newNEOFacetsKey.htm>
- 120 题原始计分键：<https://ipip.ori.org/30FacetNEO-PI-RItems.htm>
- 中文 120 题：IPIP 官网收录的华东师范大学团队译本，<https://ipip.ori.org/Mandarin%20translation%20of%20IPIP-NEO-120.htm>
- 中文初步资料：<https://ipip.ori.org/ChineseIPIP-120reliability.htm>、<https://ipip.ori.org/ChineseIPIP-120norms.htm>
- Johnson, J. A. (2014). Measuring thirty facets of the Five Factor Model with a 120-item public domain inventory: Development of the IPIP-NEO-120. Journal of Research in Personality, 51, 78–89. <https://doi.org/10.1016/j.jrp.2014.05.003>

结构化英文题目输入来自 Alheimsins 开放数据模块，MIT 许可证原文保留于 `sources/ALHEIMSINS-LICENSE-300` 和 `sources/ALHEIMSINS-LICENSE-120`。

输入版本：300 模块 `192042caaad5fd8e452bd7f25b3f1012be7bad38`；120 模块 `493546d48eb9053aca7e6c55574f4bf8033cc5a4`。最终计分键与特质归属独立对照 IPIP 原始页面，核对记录见 `sources/key-verification.json`。

完整 300 题中文适配中的匹配条目沿用公开 120 题译文，其余为本项目中文修订译稿，尚未独立开展完整中文效度验证。两道政治条目公开中文措辞与原键页面的候选人投票措辞差别见翻译记录。

## OJTS

原量表：Eric Jorgenson，Open Extended Jungian Type Scales 2.1，<https://openpsychometrics.org/tests/OJTS/>，开发资料 <https://openpsychometrics.org/tests/OJTS/development/>。

本地复用 Ac-Hanxin 开放中文项目的计分实现与十六型画像，来源检出版本 `fb776bc4de6a3bf4c16d23eac122aba7e121be27`。原 CC BY-NC-SA 4.0 许可证保留于 `LICENSE`。本项目中文题目与类型画像属于带修改的非商业改编，遵循署名、非商业使用、相同方式共享条件。计分核心保持上游语义 E/I 方向；与原站服务器结果的已知方向差别见“测试依据”。

## 界面与报告

本项目新增界面、CSS 动效、浏览器音效、WebGL 晶体、报告编排与大五人格编辑性解读为本地实现；不复制 OpenJung 网站源代码、图像或商标。报告建议为编辑性解释，不是新增的心理测量指标。

人物视觉参考 16Personalities 的类型角色、四组配色与标志道具：<https://www.16personalities.com/personality-types>。本项目重新绘制多边形路径、服装细节、姿态及动画，不使用源站图片、SVG 路径或文案；人物不是品牌授权素材包。相关角色视觉参考不构成题库或计分来源。NERIS 框架区别见 <https://www.16personalities.com/articles/our-theory>。

人物名称与基础类型画像来自上述 Ac-Hanxin 项目，新增工作、关系、学习情境与常见误解说明为棱镜编辑性内容。四组偏好的通用含义参阅 <https://www.myersbriggs.org/my-mbti-personality-type/the-16-mbti-personality-types/>，不复制其十六段类型简介。当前报告不包含 A/T、功能栈、常模排名或配对率。

整个分发包同时含以上不同许可来源，不能将 OJTS 改编内容改称商业可用 MIT 包。当前仅供自己与朋友免费、非商业使用。
