(function(){
  'use strict';
  const key='prism-experience-v1';
  let prefs={theme:'lavender',scene:'prism',sound:true,ambient:true,volume:25,motion:true,audioDefaults:2,themeDefaults:1};
  try{const saved=JSON.parse(localStorage.getItem(key));if(saved){if(['prism','orbit','dusk'].includes(saved.scene))prefs.scene=saved.scene;for(const k of ['sound','ambient','motion'])if(typeof saved[k]==='boolean'&&(k==='motion'||saved.audioDefaults===2))prefs[k]=saved[k];if(Number.isFinite(saved.volume))prefs.volume=Math.max(0,Math.min(100,saved.volume));}}catch{}
  const themes=[['classic','经典灰白','#c3c7cd'],['blue','雾白湖蓝','#a7c7d9'],['warm','奶油鼠尾草','#b7c7ab'],['lavender','清透薰衣草','#bdb2e8'],['rose','柔雾玫瑰','#d8b0c3'],['apricot','杏桃奶油','#dfbd93']];
  try{const old=JSON.parse(localStorage.getItem(key));if(old?.themeDefaults===1&&themes.some(t=>t[0]===old.theme))prefs.theme=old.theme;}catch{}
  document.querySelector('.theme-toolbar').innerHTML=themes.map(([id,name,color])=>`<button class="theme-choice" data-theme-choice="${id}" title="${name}" aria-label="${name}" aria-pressed="false" style="--swatch:${color}"><i aria-hidden="true"></i></button>`).join('');
  let context,master,ambientNodes=[],gesture=false;
  const frequencies={prism:[523.25,659.25,783.99],orbit:[293.66,440,587.33],dusk:[220,277.18,329.63]};
  function audio(){gesture=true;const Audio=window.AudioContext||window.webkitAudioContext;if(!Audio)return null;try{if(!context){context=new Audio();master=context.createGain();master.connect(context.destination);}master.gain.value=prefs.volume/100*.3;if(context.state==='suspended')context.resume().catch(()=>{});return context;}catch{return null;}}
  function tone(freq,duration=.13,delay=0,amplitude=.14){const c=audio();if(!c)return;const at=c.currentTime+delay;const osc=c.createOscillator(),gain=c.createGain();osc.type=prefs.scene==='dusk'?'sine':'triangle';osc.frequency.value=freq;gain.gain.setValueAtTime(0,at);gain.gain.linearRampToValueAtTime(amplitude,at+.009);gain.gain.exponentialRampToValueAtTime(.0001,at+duration);osc.connect(gain);gain.connect(master);osc.start(at);osc.stop(at+duration+.03);osc.onended=()=>{osc.disconnect();gain.disconnect();};}
  function play(kind='select',value=3,force=false){if(!prefs.sound&&!force)return;const notes=frequencies[prefs.scene];if(kind==='complete')notes.forEach((f,i)=>tone(f,.65,i*.16,.12));else if(kind==='page'){tone(notes[0],.22,0,.08);tone(notes[1],.26,.07,.06);}else tone(notes[(value-1)%3]*(value>3?1.25:1),prefs.scene==='dusk'?.17:.27,0,.12);}
  function stopAmbient(){ambientNodes.forEach(n=>{try{n.stop();n.disconnect();}catch{}});ambientNodes=[];}
  function ambience(){stopAmbient();if(!prefs.ambient||document.hidden||!gesture)return;const c=audio();if(!c)return;const base=frequencies[prefs.scene][0]/4;[base,base*1.5].forEach((f,i)=>{const osc=c.createOscillator(),gain=c.createGain();osc.type='sine';osc.frequency.value=f;gain.gain.setValueAtTime(0,c.currentTime);gain.gain.linearRampToValueAtTime(.035/(i+1),c.currentTime+2);osc.connect(gain);gain.connect(master);osc.start();ambientNodes.push(osc);osc.onended=()=>gain.disconnect();});}
  function persist(){try{localStorage.setItem(key,JSON.stringify(prefs));}catch{}}
  function apply(){document.body.dataset.theme=prefs.theme;document.body.dataset.motion=String(prefs.motion);document.querySelectorAll('[data-scene]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.scene===prefs.scene)));document.querySelectorAll('[data-theme-choice]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.themeChoice===prefs.theme)));document.querySelector('meta[name=theme-color]').content=getComputedStyle(document.body).getPropertyValue('--bg').trim();window.dispatchEvent(new CustomEvent('prism-motion',{detail:prefs.motion}));persist();}
  document.querySelectorAll('[data-theme-choice]').forEach(b=>b.onclick=()=>{prefs.theme=b.dataset.themeChoice;apply();});
  function animateCopy(scope=document){scope.querySelectorAll('.reading-guidance>span,.comfort>span,.save').forEach((el,lane)=>{if(el.querySelector('.motion-visual'))return;const original=el.textContent;el.textContent='';el.classList.add('ambient-copy');el.style.setProperty('--copy-phase',(lane%4)*.47+'s');const sr=document.createElement('span');sr.className='motion-sr-only';sr.textContent=original;const visual=document.createElement('span');visual.className='motion-visual';visual.setAttribute('aria-hidden','true');Array.from(original).forEach((char,i)=>{const glyph=document.createElement('span');glyph.className='motion-glyph';glyph.textContent=char;glyph.style.setProperty('--glyph-index',i);visual.append(glyph);});el.append(sr,visual);});}
  const dialog=document.querySelector('#ambience-dialog');
  document.querySelector('#ambience-trigger').addEventListener('click',()=>{for(const[id,field]of[['sound-enabled','sound'],['ambient-enabled','ambient'],['motion-enabled','motion']])document.getElementById(id).checked=prefs[field];document.querySelector('#sound-volume').value=prefs.volume;dialog.showModal();});
  document.querySelector('#close-ambience').onclick=()=>dialog.close();
  document.querySelectorAll('[data-scene]').forEach(b=>b.onclick=()=>{prefs.scene=b.dataset.scene;apply();if(prefs.sound)play('page');ambience();});
  for(const[id,field]of[['sound-enabled','sound'],['ambient-enabled','ambient'],['motion-enabled','motion']])document.getElementById(id).onchange=e=>{prefs[field]=e.target.checked;apply();if(field==='sound'&&prefs.sound)play('page');if(field==='ambient'){audio();ambience();}};
  document.querySelector('#sound-volume').oninput=e=>{prefs.volume=Number(e.target.value);if(master)master.gain.value=prefs.volume/100*.3;persist();};
  document.querySelector('#preview-sound').onclick=()=>play('complete',3,true);
  document.addEventListener('visibilitychange',()=>{if(document.hidden){stopAmbient();context?.suspend().catch(()=>{});}else if(gesture&&prefs.ambient)ambience();});
  function unlockAudio(){if(!gesture&&(prefs.sound||prefs.ambient)){audio();ambience();}}
  document.addEventListener('pointerdown',unlockAudio,{once:true});
  document.addEventListener('keydown',unlockAudio,{once:true});
  if(matchMedia('(prefers-reduced-motion: reduce)').matches)document.querySelector('#motion-note').textContent='系统已开启“减少动态效果”，菱形会保持静止。声音可独立使用。';
  apply();window.PRISM_EXPERIENCE={play,animateCopy,get prefs(){return{...prefs};}};
})();
